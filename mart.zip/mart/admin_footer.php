
<section id="footer">
            <footer>
                  <div class="about-us">
                        <h4>About Us</h4>
                        <br><br>
                        <p style="width: 90%;">
                          Lunched in 2023 Hamro Mart is Nepal's premier online shopping market place.
                         <br>
                         <br>
                          Hmaro Mart Is focused on providing an excellent customer experience 
                          ease-of-purchase,
                         comprehensive
                          customers care and hasel-free shopping and returns experience.
                        </p>
                        <br>
                        <img src="./assets/icons/location.png" alt="">Mahendranagar,Kanchanpur-Nepal</p>
                  </div>
                  <div class="contact-us">
                      <h4>Contact Us</h4>
                      <br><br>
                      <p><img  src="./assets/icons/phone-call.png" alt="">+977-9809498493</p>
                      <br>
                      <p><img  src="./assets/icons/email.png" alt="">hamro@gmail.com</p>
                      <br>
                      <p><img  src="./assets/icons/fb.png" alt="">Hamromart</p>
                  </div>

                  <div class="quick-links">
                        <h4>Quick Links</h4>
                        <br><br>
                        <p><a href="admin.php">Home</a></p>
                        <p><a href="admin_order.php">Order</a></p>
                        <p><a href="admin_add_product.php">Add Products</a></p>
                        <p><a href="admin_products.php">Products</a></p>
                        <p><a href="admin_admin.php">Admin</a></p>
                        <p><a href="admin_normal_user.php">Normal User</a></p>
                  </div>
            </footer>
      </section>
      <script src="./js/app.js"></script>
      <script src="./js/close.js"></script>
</body>

</html>