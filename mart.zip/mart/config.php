<?php
//connect to data base hamro_mart
    $conn=mysqli_connect('localhost','root','','hamro_mart') or die('connection failed');
?>