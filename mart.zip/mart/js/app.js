


let profile=document.getElementById('profile');
profile.addEventListener('click',()=>{
 let details=document.querySelector('#display');
    if(details.style.display=='none')
    {
        details.style.display='block';
    }
    else{
        details.style.display='none';
    }
});


