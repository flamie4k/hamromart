//js for update products

document.querySelector('#close-update').onclick=()=>{
    document.querySelector('.update-container').style.display='none';
}
